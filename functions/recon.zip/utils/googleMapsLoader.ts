
let scriptLoaded = false;
let scriptPromise: Promise<void> | null = null;

export const loadGoogleMapsScript = (apiKey: string): Promise<void> => {
  if (scriptLoaded) {
    return Promise.resolve();
  }

  if (scriptPromise) {
    return scriptPromise;
  }

  scriptPromise = new Promise((resolve, reject) => {
    const script = document.createElement('script');
    script.src = `https://maps.googleapis.com/maps/api/js?key=${apiKey}&libraries=places`;
    script.async = true;
    script.defer = true;

    script.onload = () => {
      scriptLoaded = true;
      scriptPromise = null;
      resolve();
    };

    script.onerror = () => {
      scriptPromise = null;
      reject(new Error('Google Maps script could not be loaded.'));
    };

    document.head.appendChild(script);
  });

  return scriptPromise;
};


import React, { useState, useMemo, useCallback, useEffect, useRef } from 'react';
import { GoogleGenAI, Type } from '@google/genai';
import { motion, AnimatePresence } from 'framer-motion';
import { Search, Building2, MapPin, WandSparkles, LoaderCircle, AlertTriangle, BotMessageSquare, BrainCircuit, Target, ClipboardCopy, Link as LinkIcon } from 'lucide-react';
import type { Lead, HeroWork } from './types';
import Header from './components/Header';
import LeadCard from './components/LeadCard';
import Shimmer from './components/Shimmer';
import SpotlightInput from './components/SpotlightInput';
import IntelligenceCard from './components/IntelligenceCard';
import CopyButton from './components/CopyButton';
import ApiKeyOverlay from './components/ApiKeyOverlay';
import TroubleshootingGuide from './components/TroubleshootingGuide';
import { useTheme } from './contexts/ThemeContext';
import { useMousePosition } from './hooks/useMousePosition';
import { loadGoogleMapsScript } from './utils/googleMapsLoader';

// --- Animation Variants ---
const containerVariants = {
  hidden: { opacity: 0 },
  visible: {
    opacity: 1,
    transition: { staggerChildren: 0.07 }
  }
};

const itemVariants = {
  hidden: { opacity: 0, y: 20 },
  visible: { opacity: 1, y: 0 }
};

// --- Main App Component ---
export default function App() {
  const { theme } = useTheme();
  const mousePosition = useMousePosition();
  const placesServiceRef = useRef<google.maps.places.PlacesService | null>(null);
  
  // State Management
  const [industry, setIndustry] = useState('Production House');
  const [city, setCity] = useState('Mumbai');
  const [leads, setLeads] = useState<Lead[]>([]);
  const [selectedLead, setSelectedLead] = useState<Lead | null>(null);
  const [heroWork, setHeroWork] = useState<HeroWork | null>(null);
  const [mySkills, setMySkills] = useState('I am a drone pilot specializing in aerial cinematography.');
  const [generatedEmail, setGeneratedEmail] = useState('');
  
  // Loading and Error States
  const [isMapsReady, setIsMapsReady] = useState(false);
  const [isSearching, setIsSearching] = useState(false);
  const [isScouting, setIsScouting] = useState(false);
  const [isGenerating, setIsGenerating] = useState(false);
  const [apiError, setApiError] = useState<string | null>(null);
  const [searchError, setSearchError] = useState<string | null>(null);

  const apiKey = 'AIzaSyDtKmdh4gLkO49BOqfNOQWz3b_CXoKKIZE';

  useEffect(() => {
    if (apiKey && apiKey !== 'YOUR_API_KEY_HERE') {
      loadGoogleMapsScript(apiKey)
        .then(() => {
          const mapElement = document.createElement('div');
          placesServiceRef.current = new google.maps.places.PlacesService(mapElement);
          setIsMapsReady(true);
        })
        .catch(err => {
          console.error("Google Maps Script Loader Error:", err);
          setSearchError("MAPS_SCRIPT_LOAD_FAILED");
        });
    }
  }, [apiKey]);

  // --- API Interactions ---
  const handleSearch = useCallback(async () => {
    if (!isMapsReady || !placesServiceRef.current) {
      setSearchError("Maps service is not ready. This is often due to an API key issue.");
      return;
    }
    setIsSearching(true);
    setSearchError(null);
    setLeads([]);
    setSelectedLead(null);

    const request: google.maps.places.TextSearchRequest = {
      query: `"${industry}" in ${city}`,
    };

    placesServiceRef.current.textSearch(request, (results, status) => {
      if (status === google.maps.places.PlacesServiceStatus.OK && results) {
        const newLeads: Lead[] = results
          .filter(result => result.name && result.place_id && result.website)
          .map((result) => {
            let hostname = result.website!;
            try {
              // Defensively parse the URL to prevent crashes
              hostname = new URL(result.website!).hostname;
            } catch (e) {
              console.warn(`Invalid URL found for ${result.name}: ${result.website}`);
            }
            return {
              id: result.place_id!,
              placeId: result.place_id!,
              companyName: result.name!,
              website: hostname,
              status: 'New',
              industry: industry,
            };
          });
        setLeads(newLeads);
        if (newLeads.length === 0) {
          setSearchError("No businesses found with a website for this search. Try a different industry or city.");
        }
      } else {
        // This is the critical error handling part.
        console.error(`Google Maps Search Failed. Status: ${status}`);
        setSearchError(status); // Store the specific error status
      }
      setIsSearching(false);
    });
  }, [industry, city, isMapsReady]);

  const fetchHeroWork = useCallback(async (lead: Lead) => {
    if (!apiKey || apiKey === 'YOUR_API_KEY_HERE') return;
    setIsScouting(true);
    setHeroWork(null);
    setApiError(null);

    const prompt = `Analyze the company "${lead.companyName}" with the website "${lead.website}". Identify their single most famous or impactful "hero product" or "hero work" (e.g., a specific film, ad campaign, software, or physical product). 
    
    Respond ONLY with a single, clean JSON object of the format: {"title": "The work's title", "description": "A brief, one-sentence summary of its significance."}. Do not include any other text, explanations, or markdown formatting.`;

    try {
      const ai = new GoogleGenAI({ apiKey, vertexai: true });
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: { role: 'user', parts: [{ text: prompt }] },
        config: {
          tools: [{ googleSearch: {} }],
        }
      });

      const sources = response.candidates?.[0]?.groundingMetadata?.groundingChunks
        ?.map(chunk => chunk.web)
        .filter((source): source is { uri: string; title: string } => !!source?.uri) ?? [];
      
      let textResponse = response.text.trim();
      if (textResponse.startsWith('```json')) {
        textResponse = textResponse.substring(7, textResponse.length - 3).trim();
      }
      
      const workData = JSON.parse(textResponse);
      setHeroWork({ ...workData, sources });

    } catch (error) {
      console.error("Gemini Scouting Error:", error);
      setApiError(error instanceof Error ? error.message : "AI failed to analyze the company. The response might not be valid JSON.");
    } finally {
      setIsScouting(false);
    }
  }, [apiKey]);

  const handleGenerateEmail = useCallback(async () => {
    if (!selectedLead || !mySkills || !heroWork) {
      setApiError("Please select a lead and ensure scouting is complete.");
      return;
    }
    if (!apiKey || apiKey === 'YOUR_API_KEY_HERE') return;

    setIsGenerating(true);
    setGeneratedEmail('');
    setApiError(null);

    const prompt = `You are a helpful assistant for a freelancer pitching their services. Your task is to write a concise, professional, and compelling cold email.
      **Freelancer's Skill:** "${mySkills}"
      **Target Company:** "${selectedLead.companyName}"
      **Company's Famous Work:** They are known for their work on "${heroWork.title}".
      **Instructions:**
      1. Start with a polite and direct greeting (e.g., "Hi ${selectedLead.companyName} Team,").
      2. Briefly mention your admiration for their work on "${heroWork.title}".
      3. Directly connect the freelancer's skill to their work, suggesting how it could enhance their future projects.
      4. Keep the email under 150 words.
      5. End with a clear call to action, like suggesting a brief chat.
      6. Maintain a professional and enthusiastic tone.`;

    try {
      const ai = new GoogleGenAI({ apiKey, vertexai: true });
      const response = await ai.models.generateContent({
        model: 'gemini-2.5-flash',
        contents: { role: 'user', parts: [{ text: prompt }] },
      });
      setGeneratedEmail(response.text);
    } catch (error) {
      console.error("Gemini Email Gen Error:", error);
      setApiError(error instanceof Error ? error.message : "An unknown error occurred.");
    } finally {
      setIsGenerating(false);
    }
  }, [selectedLead, mySkills, heroWork, apiKey]);

  const handleSelectLead = (lead: Lead) => {
    setSelectedLead(lead);
    setGeneratedEmail('');
    fetchHeroWork(lead);
  };

  if (!apiKey || apiKey === 'YOUR_API_KEY_HERE') {
    return <ApiKeyOverlay />;
  }

  return (
    <div className="flex flex-col h-screen font-sans text-light-text dark:text-dark-text">
      <Header />
      <div className="flex flex-1 overflow-hidden">
        {/* Left Panel */}
        <aside className="w-full md:w-1/3 lg:w-1/4 border-r border-light-border dark:border-dark-border flex flex-col">
          <div className="p-4 space-y-4">
            <SpotlightInput id="industry" label="Industry" icon={Building2} value={industry} onChange={(e) => setIndustry(e.target.value)} placeholder="e.g., Production House" />
            <SpotlightInput id="city" label="City" icon={MapPin} value={city} onChange={(e) => setCity(e.target.value)} placeholder="e.g., Mumbai" />
            <button onClick={handleSearch} disabled={isSearching || !isMapsReady} className="w-full flex items-center justify-center gap-2 bg-accent-500 text-white font-semibold py-2.5 px-4 rounded-lg hover:bg-accent-600 transition-colors disabled:bg-gray-500 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-accent-500 focus:ring-offset-2 focus:ring-offset-light-bg dark:focus:ring-offset-dark-bg animate-glow">
              {isSearching ? <LoaderCircle className="animate-spin" size={20} /> : <Search size={20} />}
              {isSearching ? 'Searching...' : (isMapsReady ? 'Find Leads' : 'Connecting to Google...')}
            </button>
          </div>
          <div className="h-px bg-gradient-to-r from-transparent via-light-border dark:via-dark-border to-transparent"></div>
          <div className="flex-1 overflow-y-auto p-4">
            {isSearching && <div className="space-y-3">{Array.from({ length: 4 }).map((_, i) => <Shimmer key={i} className="h-20 w-full" />)}</div>}
            <AnimatePresence>
              {!isSearching && leads.length > 0 && (
                <motion.div variants={containerVariants} initial="hidden" animate="visible" className="space-y-3">
                  {leads.map(lead => (
                    <motion.div key={lead.id} variants={itemVariants}>
                      <LeadCard lead={lead} isSelected={selectedLead?.id === lead.id} onSelect={handleSelectLead} />
                    </motion.div>
                  ))}
                </motion.div>
              )}
            </AnimatePresence>
            {!isSearching && leads.length === 0 && (
              <div className="text-center text-light-text-secondary dark:text-dark-text-secondary pt-10 px-4">
                {searchError ? (
                  <TroubleshootingGuide errorStatus={searchError} />
                ) : (
                  <>
                    <h3 className="font-semibold text-light-text dark:text-dark-text">Ready for Recon</h3>
                    <p className="text-sm mt-1">Define your target industry and location to uncover new opportunities.</p>
                  </>
                )}
              </div>
            )}
          </div>
        </aside>

        {/* Right Panel */}
        <main className="w-full md:w-2/3 lg:w-3/4 p-6 overflow-y-auto bg-light-bg dark:bg-dark-bg relative">
          {theme === 'dark' && <motion.div className="absolute inset-0 z-0" style={{ background: `radial-gradient(600px at ${mousePosition.x}px ${mousePosition.y}px, rgba(20, 184, 166, 0.15), transparent 80%)` }} animate={{ background: `radial-gradient(600px at ${mousePosition.x}px ${mousePosition.y}px, rgba(20, 184, 166, 0.15), transparent 80%)` }} transition={{ type: 'tween', ease: 'backOut', duration: 0.5 }} />}
          <AnimatePresence mode="wait">
            {!selectedLead ? (
              <motion.div key="empty" initial={{ opacity: 0 }} animate={{ opacity: 1 }} exit={{ opacity: 0 }} className="flex flex-col items-center justify-center h-full text-light-text-secondary dark:text-dark-text-secondary text-center">
                <BrainCircuit size={48} className="mb-4" />
                <h2 className="text-2xl font-semibold text-light-text dark:text-dark-text">Intelligence Pane</h2>
                <p>Your mission brief will appear here once a target is selected.</p>
              </motion.div>
            ) : (
              <motion.div key={selectedLead.id} initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }} exit={{ opacity: 0, y: -20 }} transition={{ duration: 0.4 }} className="max-w-3xl mx-auto space-y-6 relative z-[1]">
                <IntelligenceCard icon={Target} title="The Scout" helperText="AI-surfaced intelligence on your target.">
                  <h3 className="text-2xl font-bold text-light-text dark:text-dark-text">{selectedLead.companyName}</h3>
                  {isScouting ? (
                    <div className="mt-4 space-y-3">
                      <Shimmer className="h-6 w-3/4" />
                      <Shimmer className="h-4 w-full" />
                      <Shimmer className="h-4 w-5/6" />
                    </div>
                  ) : heroWork ? (
                    <>
                      <div className="mt-4 p-4 bg-light-bg dark:bg-dark-bg rounded-lg border border-light-border dark:border-dark-border">
                        <p className="font-semibold text-light-text-secondary dark:text-dark-text-secondary text-sm">Identified Hero Work:</p>
                        <p className="text-lg text-light-text dark:text-dark-text mt-1">"{heroWork.title}"</p>
                        <p className="text-light-text-secondary dark:text-dark-text-secondary mt-1 text-sm">{heroWork.description}</p>
                      </div>
                      {heroWork.sources.length > 0 && (
                        <div className="mt-3">
                          <p className="text-xs font-semibold text-light-text-secondary dark:text-dark-text-secondary uppercase tracking-wider">Sources</p>
                          <div className="mt-2 space-y-1">
                            {heroWork.sources.map((source, i) => (
                              <a key={i} href={source.uri} target="_blank" rel="noopener noreferrer" className="flex items-center gap-2 text-xs text-accent-600 dark:text-accent-400 hover:underline truncate">
                                <LinkIcon size={12} />
                                <span>{source.title || source.uri}</span>
                              </a>
                            ))}
                          </div>
                        </div>
                      )}
                    </>
                  ) : (
                     <div className="mt-4 text-red-500 dark:text-red-400"><AlertTriangle className="inline-block mr-2" size={16} />{apiError || "Could not retrieve company intelligence."}</div>
                  )}
                </IntelligenceCard>

                <IntelligenceCard icon={WandSparkles} title="The Pitcher" helperText="Craft the perfect pitch with your unique skills.">
                  <div>
                    <label htmlFor="my-skills" className="block text-md font-medium text-light-text dark:text-dark-text">Your Core Skill</label>
                    <textarea id="my-skills" value={mySkills} onChange={(e) => setMySkills(e.target.value)} rows={3} className="mt-2 w-full bg-light-surface dark:bg-dark-surface border border-light-border dark:border-dark-border rounded-lg p-3 text-light-text dark:text-dark-text focus:ring-2 focus:ring-accent-500 focus:border-accent-500 outline-none transition-shadow" placeholder="e.g., I'm a drone pilot specializing in FPV shots..."></textarea>
                  </div>
                  <button onClick={handleGenerateEmail} disabled={isGenerating || isScouting || !heroWork} className="mt-4 w-full flex items-center justify-center gap-2 bg-accent-500 text-white font-semibold py-2.5 px-4 rounded-lg hover:bg-accent-600 transition-colors disabled:bg-gray-500 disabled:cursor-not-allowed focus:outline-none focus:ring-2 focus:ring-accent-500 focus:ring-offset-2 focus:ring-offset-light-surface dark:focus:ring-offset-dark-surface">
                    {isGenerating ? <LoaderCircle className="animate-spin" size={20} /> : <ClipboardCopy size={20} />}
                    {isGenerating ? 'Generating Pitch...' : 'Generate AI Pitch'}
                  </button>
                  <div className="mt-6">
                    <h3 className="text-md font-medium text-light-text dark:text-dark-text flex items-center gap-2">
                      <BotMessageSquare size={20} className={isGenerating ? 'animate-pulse-soft text-accent-400' : 'text-light-text-secondary dark:text-dark-text-secondary'} />
                      Generated Email
                    </h3>
                    <div className="relative mt-2">
                      {isGenerating ? (
                        <div className="p-5 space-y-3 border border-light-border dark:border-dark-border rounded-lg">
                          <Shimmer className="h-4 w-full" />
                          <Shimmer className="h-4 w-5/6" />
                          <Shimmer className="h-4 w-full" />
                          <Shimmer className="h-4 w-3/4" />
                        </div>
                      ) : (
                        <>
                          <CopyButton textToCopy={generatedEmail} />
                          <div className="p-5 whitespace-pre-wrap bg-light-bg dark:bg-dark-bg rounded-lg border border-light-border dark:border-dark-border min-h-[180px] text-light-text-secondary dark:text-dark-text-secondary text-sm leading-relaxed">
                            {apiError && !generatedEmail ? (
                              <div className="flex items-center gap-3 text-red-500 dark:text-red-400">
                                <AlertTriangle size={20} />
                                <div>
                                  <p className="font-bold text-light-text dark:text-dark-text">Error</p>
                                  <p>{apiError}</p>
                                </div>
                              </div>
                            ) : (
                              generatedEmail || <span className="text-light-text-secondary/70 dark:text-dark-text-secondary/70">Your AI-generated pitch will appear here...</span>
                            )}
                          </div>
                        </>
                      )}
                    </div>
                  </div>
                </IntelligenceCard>
              </motion.div>
            )}
          </AnimatePresence>
        </main>
      </div>
    </div>
  );
}

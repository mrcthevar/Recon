
import React from 'react';
import { Sun, Moon } from 'lucide-react';
import { motion, AnimatePresence } from 'framer-motion';
import { useTheme } from '../contexts/ThemeContext';

const ThemeToggle: React.FC = () => {
  const { theme, toggleTheme } = useTheme();

  return (
    <button
      onClick={toggleTheme}
      className="relative flex items-center h-7 w-12 rounded-full bg-light-border dark:bg-dark-surface transition-colors duration-300 focus:outline-none focus:ring-2 focus:ring-accent-500 focus:ring-offset-2 focus:ring-offset-light-bg dark:focus:ring-offset-dark-bg"
      aria-label={`Switch to ${theme === 'light' ? 'dark' : 'light'} mode`}
    >
      <motion.span
        layout
        transition={{ type: 'spring', stiffness: 700, damping: 30 }}
        className="absolute left-1 top-1 flex items-center justify-center h-5 w-5 rounded-full bg-white dark:bg-gray-700 shadow-sm"
      />
      <AnimatePresence mode="wait" initial={false}>
        <motion.div
          key={theme === 'light' ? 'sun' : 'moon'}
          initial={{ y: -20, opacity: 0, rotate: -90 }}
          animate={{ y: 0, opacity: 1, rotate: 0 }}
          exit={{ y: 20, opacity: 0, rotate: 90 }}
          transition={{ duration: 0.2 }}
          className="absolute left-1/2 top-1/2 -translate-x-1/2 -translate-y-1/2"
        >
          {theme === 'light' ? (
            <Sun size={14} className="text-yellow-500" style={{transform: 'translateX(-10px)'}} />
          ) : (
            <Moon size={14} className="text-blue-300" style={{transform: 'translateX(10px)'}} />
          )}
        </motion.div>
      </AnimatePresence>
    </button>
  );
};

export default ThemeToggle;

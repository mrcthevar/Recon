
import React from 'react';
import { Link as LinkIcon } from 'lucide-react';
import type { Lead } from '../types';

interface LeadCardProps {
  lead: Lead;
  isSelected: boolean;
  onSelect: (lead: Lead) => void;
}

const LeadCard: React.FC<LeadCardProps> = ({ lead, isSelected, onSelect }) => {
  const statusColors = {
    New: 'bg-blue-500/20 text-blue-300 border-blue-500/30',
    Warm: 'bg-yellow-500/20 text-yellow-300 border-yellow-500/30',
    Contacted: 'bg-green-500/20 text-green-300 border-green-500/30',
  };

  return (
    <div
      onClick={() => onSelect(lead)}
      className={`
        p-4 rounded-lg border cursor-pointer transition-all duration-200 relative overflow-hidden
        ${isSelected 
          ? 'bg-light-surface dark:bg-dark-surface border-accent-500 shadow-md shadow-accent-950/20' 
          : 'bg-light-surface/50 dark:bg-dark-surface/50 border-light-border dark:border-dark-border hover:bg-light-surface hover:dark:bg-dark-surface hover:border-light-border-strong hover:dark:border-dark-border-strong'}
      `}
      aria-pressed={isSelected}
      role="button"
      tabIndex={0}
      onKeyDown={(e) => (e.key === 'Enter' || e.key === ' ') && onSelect(lead)}
    >
      {isSelected && (
        <div className="absolute top-2 right-2 text-xs font-semibold px-2 py-0.5 rounded-full bg-accent-500/20 text-accent-300 border border-accent-500/30">
          Active Lead
        </div>
      )}
      <div className="flex justify-between items-start">
        <h3 className="font-semibold text-md text-light-text dark:text-dark-text pr-20">{lead.companyName}</h3>
        <span className={`text-xs font-medium px-2 py-0.5 rounded-full border ${statusColors[lead.status]}`}>
          {lead.status}
        </span>
      </div>
      <div className="flex items-center gap-2 mt-2 text-sm text-light-text-secondary dark:text-dark-text-secondary">
        <LinkIcon size={14} />
        <a 
          href={`https://${lead.website}`} 
          target="_blank" 
          rel="noopener noreferrer" 
          onClick={(e) => e.stopPropagation()}
          className="truncate hover:text-accent-500 transition-colors"
        >
          {lead.website}
        </a>
      </div>
    </div>
  );
};

export default LeadCard;

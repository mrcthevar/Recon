
import React, { InputHTMLAttributes } from 'react';
import { LucideProps } from 'lucide-react';

interface SpotlightInputProps extends InputHTMLAttributes<HTMLInputElement> {
  icon: React.ComponentType<LucideProps>;
  label: string;
}

const SpotlightInput: React.FC<SpotlightInputProps> = ({ icon: Icon, label, id, ...props }) => {
  return (
    <div>
      <label htmlFor={id} className="text-sm font-medium text-light-text-secondary dark:text-dark-text-secondary">
        {label}
      </label>
      <div className="relative mt-1">
        <Icon className="absolute left-4 top-1/2 -translate-y-1/2 text-light-text-secondary dark:text-dark-text-secondary" size={18} />
        <input
          id={id}
          {...props}
          className="w-full bg-light-surface dark:bg-dark-surface border border-light-border dark:border-dark-border rounded-lg pl-11 pr-4 py-2.5 text-light-text dark:text-dark-text placeholder:text-light-text-secondary placeholder:dark:text-dark-text-secondary/50 focus:ring-2 focus:ring-accent-500 focus:border-accent-500 outline-none transition-shadow"
        />
      </div>
    </div>
  );
};

export default SpotlightInput;

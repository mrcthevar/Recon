
import React from 'react';
import { AlertTriangle } from 'lucide-react';

const ApiKeyOverlay: React.FC = () => {
  return (
    <div className="absolute inset-0 z-50 flex items-center justify-center bg-light-bg/80 dark:bg-dark-bg/80 backdrop-blur-sm">
      <div className="max-w-md p-8 text-center bg-light-surface dark:bg-dark-surface border border-light-border dark:border-dark-border-strong rounded-lg shadow-2xl">
        <AlertTriangle className="mx-auto h-12 w-12 text-yellow-500" />
        <h2 className="mt-4 text-2xl font-bold text-light-text dark:text-dark-text">
          Configuration Required
        </h2>
        <p className="mt-2 text-md text-light-text-secondary dark:text-dark-text-secondary">
          This application requires a Google Cloud API key with both the Gemini API and Google Maps Places API enabled.
        </p>
        <p className="mt-4 text-sm text-light-text-secondary dark:text-dark-text-secondary">
          Please set the <code className="px-1 py-0.5 font-mono text-sm bg-light-border dark:bg-dark-border-strong rounded">API_KEY</code> environment variable to continue.
        </p>
      </div>
    </div>
  );
};

export default ApiKeyOverlay;

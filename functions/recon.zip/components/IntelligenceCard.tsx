
import React, { ReactNode } from 'react';
import { LucideProps } from 'lucide-react';

interface IntelligenceCardProps {
  icon: React.ComponentType<LucideProps>;
  title: string;
  helperText: string;
  children: ReactNode;
}

const IntelligenceCard: React.FC<IntelligenceCardProps> = ({ icon: Icon, title, helperText, children }) => {
  return (
    <section className="bg-light-surface dark:bg-dark-surface rounded-xl border border-light-border dark:border-dark-border shadow-sm dark:shadow-none dark:backdrop-blur-xl transition-all duration-300">
      <div className="p-5 border-b border-light-border dark:border-dark-border">
        <div className="flex items-center gap-3">
          <Icon className="text-accent-500" size={20} />
          <h2 className="text-lg font-semibold text-light-text dark:text-dark-text">{title}</h2>
        </div>
        <p className="text-sm text-light-text-secondary dark:text-dark-text-secondary mt-1 ml-8">{helperText}</p>
      </div>
      <div className="p-5">
        {children}
      </div>
    </section>
  );
};

export default IntelligenceCard;

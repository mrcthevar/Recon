
import React from 'react';

interface ShimmerProps {
  className?: string;
}

const Shimmer: React.FC<ShimmerProps> = ({ className }) => {
  return (
    <div className={`animate-shimmer bg-[linear-gradient(to_right,theme(colors.light.border)_8%,theme(colors.light.surface)_18%,theme(colors.light.border)_33%)] dark:bg-[linear-gradient(to_right,theme(colors.dark.border)_8%,theme(colors.dark.surface)_18%,theme(colors.dark.border)_33%)] bg-[length:1000px_100%] rounded-lg ${className}`} />
  );
};

export default Shimmer;

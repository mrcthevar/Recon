
import React, { useState } from 'react';
import { Copy, Check } from 'lucide-react';

interface CopyButtonProps {
  textToCopy: string;
}

const CopyButton: React.FC<CopyButtonProps> = ({ textToCopy }) => {
  const [isCopied, setIsCopied] = useState(false);

  const handleCopy = async () => {
    if (!textToCopy) return;
    await navigator.clipboard.writeText(textToCopy);
    setIsCopied(true);
    setTimeout(() => setIsCopied(false), 2000);
  };

  return (
    <button
      onClick={handleCopy}
      disabled={!textToCopy || isCopied}
      className="absolute top-3 right-3 flex items-center gap-1.5 px-2 py-1 text-xs rounded-md bg-light-border/80 dark:bg-dark-border-strong/80 text-light-text-secondary dark:text-dark-text-secondary hover:bg-light-border dark:hover:bg-dark-border-strong transition-colors disabled:opacity-70 disabled:cursor-not-allowed"
    >
      {isCopied ? <Check size={14} className="text-green-500" /> : <Copy size={14} />}
      {isCopied ? 'Copied!' : 'Copy'}
    </button>
  );
};

export default CopyButton;


import React from 'react';
import { Sparkles } from 'lucide-react';
import ThemeToggle from './ThemeToggle';
import { useTheme } from '../contexts/ThemeContext';

const Header: React.FC = () => {
  const { theme } = useTheme();

  return (
    <header className="flex items-center justify-between p-4 border-b border-light-border dark:border-dark-border-strong sticky top-0 bg-light-bg/80 dark:bg-dark-bg/80 backdrop-blur-lg z-10">
      <div className="flex items-center gap-3">
        <div>
          <h1 className="text-xl font-bold tracking-tighter text-light-text dark:text-dark-text">Recon</h1>
          <p className="text-xs text-light-text-secondary dark:text-dark-text-secondary -mt-1">Sales Intelligence for Creators</p>
        </div>
      </div>
      <div className="absolute left-1/2 -translate-x-1/2 hidden md:block">
        <div className="px-3 py-1 text-xs font-medium rounded-full bg-light-surface dark:bg-dark-surface border border-light-border dark:border-dark-border text-light-text-secondary dark:text-dark-text-secondary">
          {theme === 'light' ? 'Day Mode' : 'Night Mode'}
        </div>
      </div>
      <div className="flex items-center gap-4">
        <div className="flex items-center gap-1.5 px-2 py-1 text-xs rounded-full bg-accent-950 text-accent-300 border border-accent-800">
          <Sparkles size={14} className="text-accent-400" />
          <span>Powered by AI</span>
        </div>
        <ThemeToggle />
      </div>
    </header>
  );
};

export default Header;


import React from 'react';
import { AlertTriangle, CheckCircle, ExternalLink } from 'lucide-react';

interface TroubleshootingGuideProps {
  errorStatus: string;
}

const TroubleshootingGuide: React.FC<TroubleshootingGuideProps> = ({ errorStatus }) => {
  const getErrorMessage = () => {
    switch (errorStatus) {
      case 'REQUEST_DENIED':
        return "Google's server denied the request. This is the most common error and is almost always caused by an issue with the API key itself or its project settings.";
      case 'INVALID_REQUEST':
        return "The request sent to Google was considered invalid. This can sometimes happen with misconfigured APIs.";
      default:
        return `An unexpected error occurred. Google Maps returned the status code: ${errorStatus}.`;
    }
  };

  return (
    <div className="mt-4 p-5 bg-yellow-500/10 dark:bg-yellow-900/20 border border-yellow-500/20 rounded-lg">
      <div className="flex items-start gap-3">
        <AlertTriangle className="h-6 w-6 text-yellow-500 flex-shrink-0 mt-1" />
        <div>
          <h3 className="text-lg font-semibold text-light-text dark:text-dark-text">API Connection Failed</h3>
          <p className="mt-1 text-sm text-yellow-700 dark:text-yellow-300">{getErrorMessage()}</p>
        </div>
      </div>

      <div className="mt-4 pl-9">
        <h4 className="font-semibold text-light-text dark:text-dark-text">Troubleshooting Checklist:</h4>
        <p className="text-xs text-light-text-secondary dark:text-dark-text-secondary mb-3">Please check the following in your Google Cloud Project:</p>
        <ul className="space-y-3 text-sm">
          <li className="flex items-start gap-3">
            <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold">Billing Is Enabled:</span> A valid billing account (like the free trial) must be linked to your project, even if you don't expect to pay.
            </div>
          </li>
          <li className="flex items-start gap-3">
            <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold">APIs Are Enabled:</span> Verify that both the <span className="font-mono text-xs px-1 py-0.5 bg-light-border dark:bg-dark-border-strong rounded">Places API</span> and <span className="font-mono text-xs px-1 py-0.5 bg-light-border dark:bg-dark-border-strong rounded">Vertex AI API</span> are enabled.
            </div>
          </li>
          <li className="flex items-start gap-3">
            <CheckCircle className="h-5 w-5 text-green-500 flex-shrink-0 mt-0.5" />
            <div>
              <span className="font-semibold">API Key Restrictions:</span> If you set restrictions, ensure they are correct. For testing, it's safest to temporarily remove all "Application restrictions" (like HTTP referrers) to see if that fixes the issue.
            </div>
          </li>
        </ul>
        <a href="https://console.cloud.google.com/apis/dashboard" target="_blank" rel="noopener noreferrer" className="inline-flex items-center gap-2 mt-4 text-sm font-semibold text-accent-600 dark:text-accent-400 hover:underline">
          Go to Google Cloud Dashboard <ExternalLink size={14} />
        </a>
      </div>
    </div>
  );
};

export default TroubleshootingGuide;


export type Theme = 'light' | 'dark';

export interface Lead {
  id: string; // Now using Google Place ID
  placeId: string;
  companyName: string;
  website: string;
  status: 'Warm' | 'New' | 'Contacted';
  industry: string;
}

export interface Source {
  uri: string;
  title: string;
}

export interface HeroWork {
  title: string;
  description: string;
  sources: Source[];
}
